# Baritone Emergency Stop — Fabric 1.21.1

Một chức năng duy nhất:

**F10 → dừng pathing/tác vụ của Baritone primary instance.**

Mod không thêm command, GUI, config, automation hay logic pathfinding riêng.

## Yêu cầu

- Minecraft 1.21.1
- Fabric Loader
- Fabric API 0.116.15+1.21.1
- Baritone 1.11.3 (Fabric, dành cho 1.21/1.21.1)
- Java 21

## Build

1. Đặt file API chính thức `baritone-api-fabric-1.11.3.jar` vào thư mục `libs/`.
2. Chạy `gradle build` hoặc dùng Gradle Wrapper nếu mày đã tạo wrapper cho project.
3. File mod nằm trong `build/libs/`.

## Phím

Mặc định: **F10**.

Có thể đổi trong:
Options → Controls → Key Binds

## Cách dừng

Phím F10 gọi trực tiếp:

`BaritoneAPI.getProvider().getPrimaryBaritone().getPathingBehavior().cancelEverything();`

Baritone public API có `cancelEverything()` để hủy pathing hiện tại. Không gửi chat command.
